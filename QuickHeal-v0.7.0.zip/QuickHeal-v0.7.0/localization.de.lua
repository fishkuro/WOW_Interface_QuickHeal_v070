if (GetLocale() == "deDE") then

-- Shaman
QUICKHEAL_SPELL_LESSER_HEALING_WAVE = 'Geringe Welle der Heilung';
QUICKHEAL_SPELL_HEALING_WAVE = 'Welle der Heilung';

-- Priest
QUICKHEAL_SPELL_LESSER_HEAL = 'Geringes Heilen';
QUICKHEAL_SPELL_HEAL = 'Heilen';
QUICKHEAL_SPELL_GREATER_HEAL = 'Gro\195\159e Heilung';
QUICKHEAL_SPELL_FLASH_HEAL = 'Blitzheilung';

-- Paladin
QUICKHEAL_SPELL_HOLY_LIGHT = 'Heiliges Licht';
QUICKHEAL_SPELL_FLASH_OF_LIGHT = 'Lichtblitz';
QUICKHEAL_SPELL_HOLY_SHOCK = 'Heiliger Schock';

-- Druid
QUICKHEAL_SPELL_HEALING_TOUCH = 'Heilende Ber\195\188hrung';
QUICKHEAL_SPELL_REGROWTH = 'Nachwachsen';

end
